export class Parenttask {
    ParentTaskName:string;
    ParentID:number;
}
