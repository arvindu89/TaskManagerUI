export class User {
    UserID:number;
    FirstName:String;
    LastName:String;
    EmployeeID:number;
    ProjectID:number;
    TaskID:number;
}