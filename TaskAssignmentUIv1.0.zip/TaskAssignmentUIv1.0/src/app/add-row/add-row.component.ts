import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-row',
  templateUrl: './add-row.component.html',
  styleUrls: ['./add-row.component.css']
})
export class AddRowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
