﻿using ProjectManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManagementAPI.DataAccess
{
    public class Repository
    {
        private ExampleData_USInsuranceEntities _entity;

        public Repository()
        {
            _entity = new ExampleData_USInsuranceEntities();
        }

        #region Task
        public List<TaskModel> SearchTask(string projectName, string sortField, bool ascending)
        {
            var query = (from t in _entity.Tasks
                         join p in _entity.ParentTasks on t.Parent_ID equals p.Parent_ID
                         join pr in _entity.Projects on t.Project_ID equals pr.Project_ID
                         join u in _entity.Users on t.Task_ID equals u.Task_ID
                         select new TaskModel()
                         {
                             TaskID = t.Task_ID,
                             TaskName = t.Task1,
                             EndDate = t.End_Date,
                             StartDate = t.Start_Date,
                             Status = t.Status,
                             ParentTaskID = t.Parent_ID,
                             ParentTaskName = p.Parent_Task,
                             Priority = t.Priority,
                             ProjectID = t.Project_ID,
                             ProjectName = pr.Project1,
                             UserID = u.User_ID,
                             DisplayName = u.First_Name + " " + u.Last_Name
                         });

            if (!string.IsNullOrEmpty(projectName))
            {
                query = query.Where(i => i.ProjectName.Contains(projectName));
            }

            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "startdate")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.StartDate);
                }
                else
                {
                    query = query.OrderByDescending(i => i.StartDate);
                }
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "enddate")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.EndDate);
                }
                else
                {
                    query = query.OrderByDescending(i => i.EndDate);
                }
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "priority")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.Priority);
                }
                else
                {
                    query = query.OrderByDescending(i => i.Priority);
                }
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "status")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.Status);
                }
                else
                {
                    query = query.OrderByDescending(i => i.Status);
                }
            }

            List<TaskModel> taskModelList = query.ToList();
            return taskModelList;
        }

        public List<ParentTaskModel> GetParentList()
        {
            List<ParentTaskModel> parentTasks = (from p in _entity.ParentTasks
                                                 select new ParentTaskModel
                                                 {
                                                     ParentTaskID = p.Parent_ID,
                                                     ParentTaskName = p.Parent_Task
                                                 }).ToList();
            return parentTasks;
        }

        public int AddNewTask(TaskModel taskModel)
        {
            Task task = new Task();
            task.Task1 = taskModel.TaskName;
            task.Project_ID = taskModel.ProjectID;
            task.Status = taskModel.Status;
            task.Parent_ID = taskModel.ParentTaskID;
            task.Priority = taskModel.Priority;
            task.Start_Date = taskModel.StartDate;
            task.End_Date = taskModel.EndDate;
            _entity.Tasks.Add(task);
            _entity.SaveChanges();

            return task.Task_ID;
        }

        public bool UpdateTask(TaskModel taskModel)
        {
            Task task = (from t in _entity.Tasks
                         where t.Task_ID == taskModel.TaskID
                         select t).FirstOrDefault();
            if (task != null)
            {
                task.Task1 = taskModel.TaskName;
                task.Status = taskModel.Status;
                task.Parent_ID = taskModel.ParentTaskID;
                task.Project_ID = taskModel.ProjectID;
                task.Priority = taskModel.Priority;
                task.Start_Date = taskModel.StartDate;
                task.End_Date = taskModel.EndDate;                
                _entity.SaveChanges();
                return true;
            }
            return false;
        }

        #endregion

        #region Project
        public List<ProjectModel> SearchProjectList(string projectName, string sortField, bool ascending)
        {
            var query = (from p in _entity.Projects                        
                         select new ProjectModel()
                         {
                             ProjectName = p.Project1,
                             EndDate = p.End_Date,
                             StartDate = p.Start_Date,
                             Priority = p.Priority,
                             Project_ID = p.Project_ID,
                             NoOfTask = p.Tasks.Count(),
                             CompletedTask = p.Tasks.Where(s => s.Status == true).Count()
                         });

            if (!string.IsNullOrEmpty(projectName))
            {
                query = query.Where(s => s.ProjectName.Contains(projectName));
            }

            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "startdate")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.StartDate);
                }
                else
                {
                    query = query.OrderByDescending(i => i.StartDate);
                }
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "enddate")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.EndDate);
                }
                else
                {
                    query = query.OrderByDescending(i => i.EndDate);
                }
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "priority")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.Priority);
                }
                else
                {
                    query = query.OrderByDescending(i => i.Priority);
                }
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "completed")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.CompletedTask);
                }
                else
                {
                    query = query.OrderByDescending(i => i.CompletedTask);
                }
            }
            return query.ToList();
        }

        public bool DeleteProject(ProjectModel projectModel)
        {
            var project = _entity.Projects.Where(s => s.Project_ID == projectModel.Project_ID).FirstOrDefault();
            if(project != null)
            {
                var tasks = _entity.Tasks.Where(s => s.Project_ID == project.Project_ID).ToList();
                _entity.Tasks.RemoveRange(tasks);
                var users = _entity.Users.Where(s => s.Project_ID == project.Project_ID).ToList();
                _entity.Users.RemoveRange(users);
                _entity.Projects.Remove(project);
                _entity.SaveChanges();

                return true;
            }
            return false;
        }
        
        public bool UpdateProject(ProjectModel projectModel, int userID)
        {
            var project = _entity.Projects.Where(s => s.Project_ID == projectModel.Project_ID).FirstOrDefault();
            var user = _entity.Users.Where(s => s.User_ID == userID).FirstOrDefault();
            if(project != null)
            {
                project.Project1 = projectModel.ProjectName;
                project.End_Date = projectModel.EndDate;
                project.Start_Date = projectModel.StartDate;
                project.Priority = projectModel.Priority;                
                return true;
            }
            return false;
        }
        
        #endregion

        #region User
        public List<UserModel> SearchUserList(string userName, string sortField, bool ascending)
        {
            var query = (from p in _entity.Users
                         select new UserModel()
                         {
                             UserID = p.User_ID,
                             EmployeeID = p.Employee_ID,
                             FirstName = p.First_Name,
                             LastName = p.Last_Name,
                             ProjectID = p.Project_ID,
                             TaskID = p.Task_ID
                         });

            if (!string.IsNullOrEmpty(userName))
            {
                query = query.Where(s => (s.FirstName.Contains(userName) || s.LastName.Contains(userName)));
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "firstname")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.FirstName);
                }
                else
                {
                    query = query.OrderByDescending(i => i.FirstName);
                }
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "lastname")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.LastName);
                }
                else
                {
                    query = query.OrderByDescending(i => i.LastName);
                }
            }
            if (!string.IsNullOrEmpty(sortField) && sortField.ToLower() == "employeeid")
            {
                if (ascending)
                {
                    query = query.OrderBy(i => i.EmployeeID);
                }
                else
                {
                    query = query.OrderByDescending(i => i.EmployeeID);
                }
            }           

            return query.ToList();
        }

        public bool AddUser(UserModel userModel)
        {
            User user = new User();
            try
            {
                user.First_Name = userModel.FirstName;
                user.Last_Name = userModel.LastName;
                user.Employee_ID = userModel.EmployeeID;
                user.Project_ID = userModel.ProjectID != 0 ? userModel.ProjectID : null;
                user.Task_ID = userModel.TaskID != 0 ? userModel.TaskID : null;
                _entity.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool UpdateUser(UserModel userModel)
        {
            var user = _entity.Users.Where(s => s.User_ID == userModel.UserID).FirstOrDefault();
            if (user != null)
            {
                user.First_Name = userModel.FirstName;
                user.Last_Name = userModel.LastName;
                user.Employee_ID = userModel.EmployeeID;
                user.Project_ID = userModel.ProjectID;
                user.Task_ID = userModel.TaskID;
                _entity.SaveChanges();
                return true;
            }
            return false;
        }

        public bool DeleteUser(int id)
        {
            var user = _entity.Users.Where(s => s.User_ID == id).FirstOrDefault();
            if (user != null)
            {
                _entity.Users.Remove(user);
                _entity.SaveChanges();
                return true;
            }
            return false;
        }
        #endregion
    }
}