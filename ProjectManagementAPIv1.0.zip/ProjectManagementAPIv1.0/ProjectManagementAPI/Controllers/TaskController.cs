﻿using ProjectManagementAPI.DataAccess;
using ProjectManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ProjectManagementAPI.Controllers
{
    public class TaskController : ApiController
    {
        [HttpGet]
        [ActionName("Search")]
        public HttpResponseMessage SearchTask(string projectName = null, string sortField = null, bool? ascending = null)
        {
            try
            {
                Repository repository = new Repository();
                return Request.CreateResponse(HttpStatusCode.OK, repository.SearchTask(projectName, sortField, ascending));
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }

        [ActionName("GetParentList")]
        public HttpResponseMessage GetParentList()
        {
            try
            {
                Repository repository = new Repository();
                return Request.CreateResponse(HttpStatusCode.OK, repository.GetParentList());
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }

        [HttpPost]
        [ActionName("UpdateTask")]
        public HttpResponseMessage UpdateTask([FromBody]TaskModel task)
        {
            try
            {
                Repository repository = new Repository();
                return Request.CreateResponse(HttpStatusCode.OK, repository.UpdateTask(task));
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }

        [HttpPost]
        [ActionName("AddTask")]
        public HttpResponseMessage AddTask([FromBody]TaskModel task)
        {
            try
            {
                Repository repository = new Repository();
                return Request.CreateResponse(HttpStatusCode.OK, repository.AddNewTask(task));
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }
    }

}
