import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import { User } from '../model/user';
import { Project } from '../model/project';
import { Task } from '../model/task';

@Injectable({
  providedIn: 'root'
})
export class ProjectManagementService {
  serviceurl:string ="http://localhost/ProjectMangerAPI/api/";
  taskAPI:string= this.serviceurl + "tasks/";
  userAPI:string= this.serviceurl + "user/";
  projectAPI:string= this.serviceurl + "project/";

  constructor(private http:HttpClient) { }

  GetAllUsers():Observable<any>
  {
    //return this.http.get(this.userAPI+"GetAllUsers").pipe(map((res:Response)=>res))
    return this.http.get("assets/data/userList.json").pipe(map((res:Response)=>res))
  }

  AddUser(item:User):Observable<any>
  {
    //assets/data/tasklist.json
    return this.http.post(this.userAPI+"SaveUser",item).pipe(map((res:Response)=>res))    
  }

  UpdateUser(item:User):Observable<any>
  {
    var data={id:item.UserID,value:item}
    return this.http.put(this.userAPI+"UpdateUser",item).pipe(map((res:Response)=>res))
  }
  GetUserDetails(id:number):Observable<any>
  {
    return this.http.get(this.userAPI+"GetUserDetails?id="+id).pipe(map((res:Response)=>res))
  }
  DeleteUser(id:number):Observable<any>
  {
    return this.http.delete(this.userAPI+"DeleteUser?id="+id).pipe(map((res:Response)=>res))
  }

  SearchUsers(name:string):Observable<any>
  {
    return this.http.get(this.userAPI+"SearchUsersByName?name="+name).pipe(map((res:Response)=>res))
  }

  SortingUsers(name:string):Observable<any>
  {
    return this.http.get(this.userAPI+"SortingUsers?columnName="+name).pipe(map((res:Response)=>res))
  }

  // Project Service
  GetAllProjects():Observable<any>
  {
    return this.http.get(this.projectAPI+"GetAllProjects").pipe(map((res:Response)=>res))
  }

  GetProjectDetails(id:number):Observable<any>
  {
    return this.http.get(this.projectAPI+"GetprojectDetails?id="+id).pipe(map((res:Response)=>res))
  }

  SaveProject(item:Project):Observable<any>
  {
    return this.http.post(this.projectAPI+"SaveProject",item).pipe(map((res:Response)=>res)) 
  }

  UpdateProject(item:Project):Observable<any>
  {
    return this.http.put(this.projectAPI+"UpdateProject",item).pipe(map((res:Response)=>res)) 
  }

  SuspendProject(id:number):Observable<any>
  {
    return this.http.delete(this.projectAPI+"DeleteProject?id="+id).pipe(map((res:Response)=>res)) 
  }

  SearchProjects(name:string):Observable<any>
  {
    return this.http.get(this.projectAPI+"SearchProjects?name="+name).pipe(map((res:Response)=>res))
  }

  SortingProjects(name:string):Observable<any>
  {
    return this.http.get(this.projectAPI+"SortingProjects?columnName="+name).pipe(map((res:Response)=>res))
  }


  GetAllTasks():Observable<any>
  {
    return this.http.get(this.taskAPI+"GetAllTasks").pipe(map((res:Response)=>res))
  }

  Add(item:Task):Observable<any>
  {
    return this.http.post(this.taskAPI+"SaveTask",item).pipe(map((res:Response)=>res))
  }

  GetTaskDetails(id:number):Observable<any>
  {
    return this.http.get(this.taskAPI+"GetTaskDetails?id="+id).pipe(map((res:Response)=> res))
  }

  Update(item:Task):Observable<any>
  {
    return this.http.put(this.taskAPI+"UpdateTask",item).pipe(map((res:Response)=> res))
  }

  GetParentTasks():Observable<any>
  {
    return this.http.get(this.taskAPI+"GetAllParentTasks").pipe(map((res:Response)=>res))
  }

  EndTask(id:number):Observable<any>
  {
    return this.http.put(this.taskAPI+"EndTask",id).pipe(map((res:Response)=> res))
  }

  SearchTasks(name:string):Observable<any>
  {
    return this.http.get(this.taskAPI+"SearchTasks?name="+name).pipe(map((res:Response)=>res))
  }
  SortingTasks(name:string):Observable<any>
  {
    return this.http.get(this.taskAPI+"SortingTask?columnName="+name).pipe(map((res:Response)=>res))
  }
}
