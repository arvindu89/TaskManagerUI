import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/model/user';
import { ProjectManagementService } from 'src/app/service/project-management.service';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  txtSearch: string;
  form: FormGroup;
  users: User[];
  user: any;
  msg: any;
  isEdit: boolean = false;

  constructor(private service: ProjectManagementService, private router: Router) {
    this.user = new User();
  }

  ngOnInit() {
    this.service.GetAllUsers().subscribe(data => {
      this.users = data;
    });
  }

  register(form: FormGroup) {
    form.reset();
  }

  AddUser() {
    console.log(this.isEdit);
    if (this.isEdit == false) {
      console.log('Add');
      this.service.AddUser(this.user).subscribe(data => {
        this.msg = data;
        this.service.GetAllUsers().subscribe(data => {
          this.users = data;
        });
      });
    }
    else {
      console.log('update');
      this.service.UpdateUser(this.user).subscribe(data => {
        this.msg = data;
        this.service.GetAllUsers().subscribe(data => {
          this.users = data;
          this.isEdit = false;
        });
      });
    }

  }

  EditUser(item: User) {
    console.log("edit");
    console.log(item);
    // this.service.GetUserDetails(item.UserID).subscribe(data => {
    //   this.user = data;
    //   this.isEdit = true;
    // })
    this.user= item; 
  }
  DeleteUser(id: number) {
    console.log("delete");
    console.log(id);
    this.service.DeleteUser(id).subscribe(data => {
      this.msg = data;
      this.service.GetAllUsers().subscribe(data => {
        this.users = data;
      });
    })
  }

  SearchUsers() {
    this.service.SearchUsers(this.txtSearch).subscribe(data => {
      this.users = data;
    });
  }

  SortingUsers(name: string) {
    this.service.SortingUsers(name).subscribe(data => {
      this.users = data;
    });
  }
}
