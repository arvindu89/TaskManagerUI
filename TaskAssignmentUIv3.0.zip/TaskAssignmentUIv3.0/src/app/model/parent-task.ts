export class ParentTask {    
    ParentTaskID:number;
    ParentTaskName:string
}